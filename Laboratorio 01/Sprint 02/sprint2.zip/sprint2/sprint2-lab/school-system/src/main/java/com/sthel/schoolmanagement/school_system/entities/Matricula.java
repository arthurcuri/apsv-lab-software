package com.sthel.schoolmanagement.school_system.entities;

import jakarta.persistence.*;

@Entity
public class Matricula {
    @Id
    private String id;
    private boolean confirmada;

    @ManyToOne
    private Aluno aluno;
    @ManyToOne
    private Disciplina disciplina;
}