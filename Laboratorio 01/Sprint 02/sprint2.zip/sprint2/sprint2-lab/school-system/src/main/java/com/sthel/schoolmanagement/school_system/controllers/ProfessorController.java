package com.sthel.schoolmanagement.school_system.controllers;

import com.sthel.schoolmanagement.school_system.entities.Professor;
import com.sthel.schoolmanagement.school_system.services.ProfessorService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/professores")
public class ProfessorController {
    private final ProfessorService professorService;
    
    public ProfessorController(ProfessorService professorService) {
        this.professorService = professorService;
    }
    
    @GetMapping
    public List<Professor> listarProfessores() {
        return professorService.listarProfessores();
    }
}