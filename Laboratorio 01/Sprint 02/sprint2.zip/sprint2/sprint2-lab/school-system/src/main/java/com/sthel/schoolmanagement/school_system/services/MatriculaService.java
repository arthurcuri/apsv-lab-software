package com.sthel.schoolmanagement.school_system.services;

import com.sthel.schoolmanagement.school_system.entities.Matricula;
import com.sthel.schoolmanagement.school_system.repositories.MatriculaRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MatriculaService {
    private final MatriculaRepository matriculaRepository;
    
    public MatriculaService(MatriculaRepository matriculaRepository) {
        this.matriculaRepository = matriculaRepository;
    }
    
    public List<Matricula> listarMatriculas() {
        return matriculaRepository.findAll();
    }
}