package com.sthel.schoolmanagement.school_system.entities;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class Curso {
    @Id
    private String id;
    private String nome;
    private int totalCreditos;

    @OneToMany
    private List<Disciplina> disciplinas;

    public void adicionarDisciplina(Disciplina d) {}
    public void removerDisciplina(Disciplina d) {}
}