package com.sthel.schoolmanagement.school_system.services.impl;

import com.sthel.schoolmanagement.school_system.entities.Aluno;
import com.sthel.schoolmanagement.school_system.interfaces.SistemaDePagamento;
import org.springframework.stereotype.Service;

@Service
public class SistemaDePagamentoImpl implements SistemaDePagamento {
    public void enviarCobranca(Aluno a, Double valor) {}
}