package com.sthel.schoolmanagement.school_system.repositories;

import com.sthel.schoolmanagement.school_system.entities.Aluno;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AlunoRepository extends JpaRepository<Aluno, String> {}