package com.sthel.schoolmanagement.school_system.repositories;

import com.sthel.schoolmanagement.school_system.entities.Matricula;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MatriculaRepository extends JpaRepository<Matricula, String> {}