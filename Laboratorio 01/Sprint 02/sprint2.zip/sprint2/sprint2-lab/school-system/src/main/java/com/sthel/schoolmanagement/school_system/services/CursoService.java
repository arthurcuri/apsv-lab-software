package com.sthel.schoolmanagement.school_system.services;

import com.sthel.schoolmanagement.school_system.entities.Curso;
import com.sthel.schoolmanagement.school_system.repositories.CursoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CursoService {
    private final CursoRepository cursoRepository;
    
    public CursoService(CursoRepository cursoRepository) {
        this.cursoRepository = cursoRepository;
    }
    
    public List<Curso> listarCursos() {
        return cursoRepository.findAll();
    }
}