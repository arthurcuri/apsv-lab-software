package com.sthel.schoolmanagement.school_system.entities;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class Professor extends Usuario {
    @OneToMany(mappedBy = "professorResponsavel")
    private List<Disciplina> disciplinasLecionadas;

    public List<Aluno> consultarMatricula(Disciplina d) { return null; }
}