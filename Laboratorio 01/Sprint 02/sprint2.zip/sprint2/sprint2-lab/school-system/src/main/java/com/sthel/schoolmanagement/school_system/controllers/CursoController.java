package com.sthel.schoolmanagement.school_system.controllers;

import com.sthel.schoolmanagement.school_system.entities.Curso;
import com.sthel.schoolmanagement.school_system.services.CursoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cursos")
public class CursoController {
    private final CursoService cursoService;
    
    public CursoController(CursoService cursoService) {
        this.cursoService = cursoService;
    }
    
    @GetMapping
    public List<Curso> listarCursos() {
        return cursoService.listarCursos();
    }
}