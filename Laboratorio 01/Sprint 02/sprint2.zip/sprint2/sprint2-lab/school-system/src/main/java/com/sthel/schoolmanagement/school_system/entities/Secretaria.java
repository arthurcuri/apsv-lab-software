package com.sthel.schoolmanagement.school_system.entities;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class Secretaria {
    @Id
    private String id;

    public void gerarCurriculo() {}
    public List<Disciplina> verificarDisciplinasAtivas() { return null; }
    public void manterCursos(Curso c) {}
    public void manterDisciplinas(Curso c, Disciplina d) {}
}