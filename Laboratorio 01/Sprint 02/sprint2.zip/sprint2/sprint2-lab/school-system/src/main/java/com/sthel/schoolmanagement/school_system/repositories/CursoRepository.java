package com.sthel.schoolmanagement.school_system.repositories;

import com.sthel.schoolmanagement.school_system.entities.Curso;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CursoRepository extends JpaRepository<Curso, String> {}