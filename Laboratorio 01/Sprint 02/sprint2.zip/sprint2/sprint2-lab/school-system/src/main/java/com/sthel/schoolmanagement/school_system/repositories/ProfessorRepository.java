package com.sthel.schoolmanagement.school_system.repositories;

import com.sthel.schoolmanagement.school_system.entities.Professor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfessorRepository extends JpaRepository<Professor, String> {}