package com.sthel.schoolmanagement.school_system.entities;

import jakarta.persistence.*;
import java.util.List;


@Entity
public class Aluno extends Usuario {
    @ManyToMany
    private List<Disciplina> disciplinas;

    public void cancelarMatricula(Disciplina d) {}
    public void inscreverEmDisciplina(Disciplina d) {}
    public List<Disciplina> visualizarDisciplinas() { return null; }
}