package com.sthel.schoolmanagement.school_system.interfaces;

import com.sthel.schoolmanagement.school_system.entities.Aluno;

public interface SistemaDePagamento {
    void enviarCobranca(Aluno a, Double valor);
}