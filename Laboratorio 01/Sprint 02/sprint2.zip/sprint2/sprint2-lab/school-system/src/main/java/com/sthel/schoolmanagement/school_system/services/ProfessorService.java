package com.sthel.schoolmanagement.school_system.services;

import com.sthel.schoolmanagement.school_system.entities.Professor;
import com.sthel.schoolmanagement.school_system.repositories.ProfessorRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProfessorService {
    private final ProfessorRepository professorRepository;
    
    public ProfessorService(ProfessorRepository professorRepository) {
        this.professorRepository = professorRepository;
    }
    
    public List<Professor> listarProfessores() {
        return professorRepository.findAll();
    }
}