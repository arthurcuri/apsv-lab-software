package com.sthel.schoolmanagement.school_system.entities;

import jakarta.persistence.*;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class Usuario {
    @Id
    private String id;
    private String nome;
    private String email;
    private String senha;

    public void efetuarLogin(String email, String senha) {}
}