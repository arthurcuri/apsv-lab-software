package com.sthel.schoolmanagement.school_system.controllers;

import com.sthel.schoolmanagement.school_system.entities.Matricula;
import com.sthel.schoolmanagement.school_system.services.MatriculaService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/matriculas")
public class MatriculaController {
    private final MatriculaService matriculaService;
    
    public MatriculaController(MatriculaService matriculaService) {
        this.matriculaService = matriculaService;
    }
    
    @GetMapping
    public List<Matricula> listarMatriculas() {
        return matriculaService.listarMatriculas();
    }
}