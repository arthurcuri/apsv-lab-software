package com.sthel.schoolmanagement.school_system.entities;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class Disciplina {
    @Id
    private String id;
    private String nome;
    private boolean ehObrigatoria;
    private int cargaHoraria;
    private int creditos;
    private int maxAlunos;
    private int minAlunos;

    @ManyToOne
    private Professor professorResponsavel;

    @ManyToMany(mappedBy = "disciplinas")
    private List<Aluno> alunos;

    public List<Aluno> alunosInscritos() { return null; }
    public boolean verificarMinimoAlunos() { return false; }
    public boolean verificarCapacidade() { return false; }
}